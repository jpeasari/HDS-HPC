## ----------------------------------------------------------------------------------
## import Missouri FQHC shapefile
library(rgdal)
data_path <- 'MO_2018_Federally_Qualified_Health_Center_Locations'
MO_FQHC <-
  readOGR(data_path,
          'MO_2018_Federally_Qualified_Health_Center_Locations')


## ----------------------------------------------------------------------------------
## examine data
class(MO_FQHC)
summary(MO_FQHC)
head(MO_FQHC)
names(MO_FQHC)


## ----------------------------------------------------------------------------------
## get projection
proj4string(MO_FQHC)
## show map with base R
plot(MO_FQHC)


## ----------------------------------------------------------------------------------
#### Calculate distance between two clinics
## First must convert to dataframe (Easier to handle)
library(data.table)
MO_FQHC_df <-
  data.table(as.data.frame(MO_FQHC))


## ----------------------------------------------------------------------------------
## use geodesic function
## this returns distance in meters!
## divide by 1609.344 to get miles
library(geosphere)
xy <- rbind(c(0,0),
            c(90,90),
            c(10,10),
            c(-120,-45))
distm(xy,fun=distHaversine)/1609.344


## ----------------------------------------------------------------------------------
## subset to only 3 clinics for now
sites3 <-
  MO_FQHC_df[1:3,list(OBJECTID=as.character(OBJECTID),Longitude,Latitude)]


## ----------------------------------------------------------------------------------
## create distance matrix
dist_mat3 <-
  distm(sites3[,list(Longitude,Latitude)],
        fun=distHaversine)/1609.344
colnames(dist_mat3) <- sites3$OBJECTID
rownames(dist_mat3) <- sites3$OBJECTID
dist_mat3


## ----------------------------------------------------------------------------------
# generate all combinations of vector of 3 locations?
expand.grid(c(1,2,3),
            c(1,2,3),
            c(1,2,3))

# Just use the permutations function.
library(gtools)
permutations(3,3,letters[1:3])

# How many do we expect?
3*2*1


## ----------------------------------------------------------------------------------
# do this for our object IDS
perms_3 <-
  permutations(3,3,sites3$OBJECTID)


## ----------------------------------------------------------------------------------
# these are our 'paths' (routes)
# write function to calculate the distance for a single route (ith route)
# generate matrix of path steps for this route
i <- 1
i_perms_3 <- perms_3[i,]
# break apart into pairs of points defining the route
temp_mat_path <-
  rbind(i_perms_3[-length(i_perms_3)],i_perms_3[-1])
temp_mat_path
# lookup distances using this matrix and sum
sum(apply(X = temp_mat_path,
      MARGIN = 1,#2,
      FUN = function(x) dist_mat3[x[1],x[2]]))


## ----------------------------------------------------------------------------------
# write function to calculate the distance for a single route (i'th route)
path_dist_func <-
  function(pathVec,distMat) {
    temp_mat_path <-
      rbind(pathVec[-length(pathVec)],
            pathVec[-1])
    dist <- sum(apply(X = temp_mat_path,
                      MARGIN = 2,
                      FUN = function(x) distMat[x[1],x[2]]))
    return(dist)
}


## ----------------------------------------------------------------------------------
## Test function
dist_mat3
perms_3[1,]
path_dist_func(perms_3[1,],dist_mat3)
perms_3[2,]
path_dist_func(perms_3[2,],dist_mat3)
perms_3[3,]
path_dist_func(perms_3[3,],dist_mat3)


## ----------------------------------------------------------------------------------
## Apply this function to our paths (permutations)
apply(perms_3,
      MARGIN = 1,
      FUN = path_dist_func,
      distMat = dist_mat3)


## ----------------------------------------------------------------------------------
## add to path matrix
cbind(perms_3,
      apply(perms_3,
            MARGIN = 1,
            FUN = path_dist_func,
            distMat = dist_mat3))
## converted to all character! (matrix is all one type...)


## ----------------------------------------------------------------------------------
## use dataframe instead
perms_3_df <-
  data.frame(perms_3)
perms_3_df$distance <-
  apply(perms_3,
        MARGIN = 1,
        FUN = path_dist_func,
        distMat = dist_mat3)
perms_3_df

## ----------------------------------------------------------------------------------
# Find min
perms_3_df[perms_3_df$distance == min(perms_3_df$distance),]

## ----------------------------------------------------------------------------------
## what if we want to visit 8 sites?

## How many possible combinations are there?



## ----------------------------------------------------------------------------------
## implement the brute force approach to the first 8 sites as I did above. Whats the best order to visit them?


## ----------------------------------------------------------------------------------
## Implement the brute force approach for 20 sites.
## How big will the matrix be?


## what about 25 sites?


## you need a big computer!
## this is NP hard!

