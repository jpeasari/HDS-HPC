## ----------------------------------------------------------------------------------
## import Missouri FQHC shapefile
library(rgdal)
library(data.table)

data_path <- 'MO_2018_Federally_Qualified_Health_Center_Locations'
MO_FQHC <-
  readOGR(data_path,
          'MO_2018_Federally_Qualified_Health_Center_Locations')
## create data.table for later use
MO_FQHC_df <- data.table(as.data.frame(MO_FQHC))


## ----------------------------------------------------------------------------------
## examine data
class(MO_FQHC)
summary(MO_FQHC)
head(MO_FQHC)
names(MO_FQHC)


## ----------------------------------------------------------------------------------
# write function to calculate the distance for a single route (i'th route)
path_dist_func <-
  function(pathVec,distMat) {
    temp_mat_path <-
      rbind(pathVec[-length(pathVec)],
            pathVec[-1])
    dist <- sum(apply(X = temp_mat_path,
                      MARGIN = 2,
                      FUN = function(x) distMat[x[1],x[2]]))
    return(dist)
}


## ----------------------------------------------------------------------------------
factorial(20)/2


## ----------------------------------------------------------------------------------
n_calculations <- factorial(20)/2
seconds <- n_calculations/1000
seconds_in_a_year <- 60*60*24*365
years <- seconds/seconds_in_a_year
years


## ----------------------------------------------------------------------------------
## instead of searching every solution, let's just search some of the solution space.
## start with random search?
## 100 random paths using 20 sites:
## subset to 20
sites20 <-
  MO_FQHC_df[1:20,
             list(OBJECTID=as.character(OBJECTID),Longitude,Latitude)]
sites20


## ----------------------------------------------------------------------------------
## create distance matrix
library(geosphere)
dist_mat20 <-
  distm(sites20[,list(Longitude,Latitude)],
        fun=distHaversine)/1609.344
colnames(dist_mat20) <- sites20$OBJECTID
rownames(dist_mat20) <- sites20$OBJECTID
dist_mat20


## ----------------------------------------------------------------------------------
## generate random list of 2k paths to search (using all 20 sites):
set.seed(2021)
## one at a time
sample(sites20$OBJECTID,replace=F,size=20)
sample(sites20$OBJECTID,replace=F,size=20)
## Now do 2k
paths_2k <-
  unique(t(sapply(1:2000,
           function(x) sample(sites20$OBJECTID,replace=F,size=20))))


## ----------------------------------------------------------------------------------
## calculate distances for these paths
paths_2k_df <- data.table(paths_2k)
## find minimum
paths_2k_df$distance <-
  apply(paths_2k,
            MARGIN = 1,
            FUN = path_dist_func,
            distMat = dist_mat20)
paths_2k_df[distance == min(distance)]


## ----------------------------------------------------------------------------------
## create graph of our answers:
paths_2k_df[,id:=1:.N]
library(ggplot2)
ggplot(paths_2k_df,aes(x=id,y=distance)) +
  geom_point() +
  geom_hline(yintercept=min(paths_2k_df$distance),color='red')


## ----------------------------------------------------------------------------------
## Implement a genetic algorithm!
## must add fitness function to maximize, inverse of route distance (since we want to minimize distance)
library(GA)
Fitness_f <-
  function(pathVec,...) 1/path_dist_func(pathVec, ...)
GA <- ga(type = "permutation",
         fitness = Fitness_f,
         distMat = dist_mat20,
         lower = 1,
         upper = 20,
         popSize = 10,
         maxiter = 1000,
         run = 100,
         pmutation = 0.2)


## ----------------------------------------------------------------------------------
## summarize results
summary(GA)
plot(GA)


## ----------------------------------------------------------------------------------
## extract best solution
GA@solution
## extract fitness of best solution
1/GA@fitnessValue


## ----------------------------------------------------------------------------------
## check we get the same answer
path1 <-
  as.character(GA@solution[1,])
path_dist_func(path1,dist_mat20) # Yes!

